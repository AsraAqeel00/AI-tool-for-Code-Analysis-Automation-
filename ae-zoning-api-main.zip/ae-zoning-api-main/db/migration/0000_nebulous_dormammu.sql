CREATE TABLE IF NOT EXISTS "borough" (
	"id" char(1) PRIMARY KEY NOT NULL,
	"title" text NOT NULL,
	"abbr" text NOT NULL
);
