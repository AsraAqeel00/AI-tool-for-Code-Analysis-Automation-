ALTER TABLE "community_district" ALTER COLUMN "borough_id" SET NOT NULL;--> statement-breakpoint
ALTER TABLE "community_district" ALTER COLUMN "id" SET NOT NULL;