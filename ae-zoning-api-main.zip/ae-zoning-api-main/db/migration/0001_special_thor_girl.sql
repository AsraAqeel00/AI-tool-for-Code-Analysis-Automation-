CREATE TABLE IF NOT EXISTS "land_use" (
	"id" char(2) PRIMARY KEY NOT NULL,
	"description" text NOT NULL,
	"color" char(9) NOT NULL
);
