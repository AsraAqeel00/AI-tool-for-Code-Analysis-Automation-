/**
 * @description The fundamental spatial construct
 */
export type Position = number[];
