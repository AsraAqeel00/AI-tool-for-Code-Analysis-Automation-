import { Error } from "./Error";

export type NotFound = Error;
