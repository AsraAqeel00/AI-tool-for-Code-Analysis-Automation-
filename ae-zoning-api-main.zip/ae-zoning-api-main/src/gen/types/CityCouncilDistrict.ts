export type CityCouncilDistrict = {
  /**
   * @description One or two character code to represent city council districts.
   * @type string
   */
  id: string;
};
