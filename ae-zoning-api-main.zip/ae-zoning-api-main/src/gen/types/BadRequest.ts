import { Error } from "./Error";

export type BadRequest = Error;
