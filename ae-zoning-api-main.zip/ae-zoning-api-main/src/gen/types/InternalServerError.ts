import { Error } from "./Error";

export type InternalServerError = Error;
