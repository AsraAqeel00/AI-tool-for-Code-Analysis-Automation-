import { z } from "zod";

export const mvtSchema = z.coerce.string();
