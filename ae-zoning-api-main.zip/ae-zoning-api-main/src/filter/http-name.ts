export enum HttpName {
  BAD_REQUEST = "Bad Request",
  INTERNAL_SEVER_ERROR = "Internal Server Error",
  NOT_FOUND = "Not Found",
}
